/*******************************************************************************
  Main Source File

  Company:
    Microchip Technology Inc.

  File Name:
    main.c

  Summary:
    This file contains the "main" function for a project.

  Description:
    This file contains the "main" function for a project.  The
    "main" function calls the "SYS_Initialize" function to initialize the state
    machines of all modules in the system
 *******************************************************************************/

// *****************************************************************************
// *****************************************************************************
// Section: Included Files
// *****************************************************************************
// *****************************************************************************

#include <stddef.h>                     // Defines NULL
#include <stdbool.h>                    // Defines true
#include <stdlib.h>                     // Defines EXIT_FAILURE
#include <string.h>
#include "definitions.h"                // SYS function prototypes
#include "peripheral/systick/plib_systick.h"

#define WIFI_SSID       "YOUR_INFO"
#define WIFI_PASSWORD   "YOUR_INFO"

#define MQTT_BROKER     "mqtt.mediumone.com"
#define MQTT_PORT       61618           /* encrypted port */
#define MQTT_USERNAME   "xxxxxxxxxxx/xxxxxxxxxxx"
#define MQTT_PASSWORD   "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx/xxxxxxxxxxxxxxxxx"
#define MQTT_PUB_TOPIC  "0/xxxxxxxxxxx/xxxxxxxxxxx/mydevice"

#define PUB_INTERVAL_MS 3000
#define ENABLE_PUBLISH  1

// Types & constants

typedef enum {
    APP_STATE_INIT = 0,
    APP_STATE_RESET_BRIDGE,
    APP_STATE_INIT_BRIDGE,
    APP_STATE_INIT_BRIDGE_CONFIRM,
    APP_STATE_CONNECT_WIFI,
    APP_STATE_CONNECT_WIFI_CONFIRM,
    APP_STATE_CONNECT_MQTT,
    APP_STATE_CONNECT_MQTT_CONFIRM,
    APP_STATE_PUBLISH_SENSOR_DATA,
    APP_STATE_PUBLISH_SENSOR_DATA_CONFIRM,
    APP_STATE_DISCONNECT_MQTT,
    APP_STATE_DISCONNECT_WIFI,
    APP_STATE_DISCONNECT_WIFI_CONFIRM,
    APP_STATE_TIMED_DELAY,
    APP_STATE_NONE
} APP_STATE_T;

typedef struct {
    uint32_t iteration;     // iteration count
    uint32_t timestamp;     // millisecond tick count
    int buttonState;        // 1=pressed, 0=released
    uint16_t adc;           // raw ADC0 value
} SENSOR_DATA_T;

// Globals

extern SYSTICK_OBJECT systick;
extern SERCOM_USART_OBJECT sercom0USARTObj;

APP_STATE_T app_state = APP_STATE_INIT;
APP_STATE_T next_app_state = APP_STATE_NONE;
uint32_t timed_delay_start = 0;
uint32_t timed_delay_duration = 0;

bool buttonPressed = false;
uint32_t buttonPressTime = 0;

// Prototypes

void Read_Sensors(SENSOR_DATA_T *sensorData);

// Callbacks

void EIC_User_Handler(uintptr_t context)
{
    buttonPressed = true;
    buttonPressTime = systick.tickCounter;
}

// Serial USART handling

#define SERIAL_BUF_SIZE 80

char read_buffer[SERIAL_BUF_SIZE] = {0};
char current_response[SERIAL_BUF_SIZE] = {0};
char last_response[SERIAL_BUF_SIZE] = {0};
int read_pos = 0;
int write_pos = 0;
bool new_response_available = 0;
uint32_t cmd_send_time;
int fail_count = 0;

void Process_USART0(void)
{
    if (!SERCOM0_USART_ReadIsBusy()) {
        SERCOM0_USART_Read(read_buffer, sizeof(read_buffer));
    } else {
        int read_count = SERCOM0_USART_ReadCountGet();
        if (read_count > read_pos) {
            char ch = sercom0USARTObj.rxBuffer[read_pos++];
            if (ch == '\n') {  // end of response
                current_response[write_pos] = 0;
                strcpy(last_response, current_response);
                read_pos = 0;
                write_pos = 0;
                current_response[write_pos] = 0;
                sercom0USARTObj.rxBusyStatus = false;
                new_response_available = 1;
            } else if (ch != 0 && ch != '\r') {  // ignore NUL & CR, keep rest
                current_response[write_pos++] = ch;
                current_response[write_pos] = 0;
            }
        }
    }
}

void Send_Command(char *cmd)
{
    if (cmd != NULL) {
        sercom0USARTObj.rxBusyStatus = false;
        read_pos = 0;
        write_pos = 0;
        current_response[write_pos] = 0;
        new_response_available = 0;
        SERCOM0_USART_Read(read_buffer, sizeof(read_buffer));
        SERCOM0_USART_Write(cmd, strlen(cmd));
        cmd_send_time = systick.tickCounter;
    }
}

uint32_t Response_Elapsed_Time(void)
{
    return systick.tickCounter - cmd_send_time;
}

bool isOKResponse(char *p)
{
    if (strncmp(p, "OK", 2) == 0) {
        return true;
    } else {
        return false;
    }
}

APP_STATE_T new_app_state(APP_STATE_T app_state)
{
    // Return next_app_state if it's not APP_STATE_NONE,
    // otherwise return app_state
    APP_STATE_T state = app_state;
    if (next_app_state != APP_STATE_NONE) {
        state = next_app_state;
        next_app_state = APP_STATE_NONE;
    }
    return state;
}

void set_timed_delay(uint32_t delay_ms, APP_STATE_T next_state)
{
    timed_delay_start = systick.tickCounter;
    timed_delay_duration = delay_ms;
    next_app_state = next_state;
    app_state = APP_STATE_TIMED_DELAY;
}

void LED0_On(void)
{
    LED0_Clear();
}

void LED0_Off(void)
{
    LED0_Set();
}

// *****************************************************************************
// *****************************************************************************
// Section: Main Entry Point
// *****************************************************************************
// *****************************************************************************

int main ( void )
{    
    char command[256];
    SENSOR_DATA_T sensorData;
    
    /* Initialize all modules */
    SYS_Initialize ( NULL );
    
    LED0_Off();
    SYSTICK_TimerStart();
    EIC_CallbackRegister(EIC_PIN_11, EIC_User_Handler, 0);
    ADC_Enable();
    
    SYSTICK_DelayMs(3000);  // USB startup delay
    
    printf("\r\nSAMD21 Curiosity Nano Connected to Medium One IoT Platform\r\n");
    
    while ( true )
    {
        // Process USART responses
        Process_USART0();
        
        // Report button press transitions
        if (buttonPressed) {
            printf("Button pressed\r\n");
            buttonPressed = false;
        }
                
        // Maintain state machine
        switch (app_state) {
            case APP_STATE_INIT:
                app_state = APP_STATE_RESET_BRIDGE;
                break;
            case APP_STATE_RESET_BRIDGE:
                printf("Resetting bridge hardware...");
                GPIO_PA14_Clear();
                SYSTICK_DelayMs(1000);
                GPIO_PA14_Set();
                SYSTICK_DelayMs(1000);
                printf("complete\r\n");
                app_state = APP_STATE_INIT_BRIDGE;
                break;
            case APP_STATE_INIT_BRIDGE:
                printf("Initializing bridge\r\n");
                Send_Command("AT\n");
                app_state = APP_STATE_INIT_BRIDGE_CONFIRM;
                break;
            case APP_STATE_INIT_BRIDGE_CONFIRM:
                if (new_response_available && isOKResponse(last_response)) {
                    printf("Bridge initialization complete\r\n");
                    app_state = APP_STATE_CONNECT_WIFI;
                } else if (Response_Elapsed_Time() > 1000) {
                    printf("ERROR: Bridge not responding\r\n");
                    app_state = APP_STATE_RESET_BRIDGE;
                }
                break;
            case APP_STATE_CONNECT_WIFI:
                printf("Connecting to Wi-Fi\r\n");
                sprintf(command, "AT+CWIFI={\"ssid\":\"%s\",\"password\":\"%s\"}\n",
                        WIFI_SSID, WIFI_PASSWORD);
                Send_Command(command);
                app_state = APP_STATE_CONNECT_WIFI_CONFIRM;
                break;
            case APP_STATE_CONNECT_WIFI_CONFIRM:
                if (new_response_available) {
                    if (isOKResponse(last_response)) {
                        printf("Wi-Fi connect successful\r\n");
                        app_state = APP_STATE_CONNECT_MQTT;
                    } else {
                        printf("ERROR: Wi-Fi connect failed, will retry\r\n");
                        set_timed_delay(5000, APP_STATE_CONNECT_WIFI);
                    }
                } else if (Response_Elapsed_Time() > 20000) {
                    printf("ERROR: Wi-Fi connect timed out, will retry\r\n");
                    set_timed_delay(5000, APP_STATE_CONNECT_WIFI);
                }
                break;
            case APP_STATE_CONNECT_MQTT:
                printf("Connecting to MQTT broker\r\n");
                sprintf(command, "AT+CMQTT={\"host\":\"%s\",\"port\":%u,\"username\":\"%s\",\"password\":\"%s\"}\n",
                        MQTT_BROKER, MQTT_PORT, MQTT_USERNAME, MQTT_PASSWORD);
                Send_Command(command);
                app_state = APP_STATE_CONNECT_MQTT_CONFIRM;
                break;
            case APP_STATE_CONNECT_MQTT_CONFIRM:
                if (new_response_available) {
                    if (isOKResponse(last_response)) {
                        printf("MQTT connect successful\r\n");
                        app_state = APP_STATE_PUBLISH_SENSOR_DATA;
                    } else {
                        printf("ERROR: MQTT connect failed, will retry\r\n");
                        set_timed_delay(5000, APP_STATE_CONNECT_MQTT);
                    }
                } else if (Response_Elapsed_Time() > 10000) {
                    printf("ERROR: MQTT connect timed out, will retry\r\n");
                    set_timed_delay(5000, APP_STATE_CONNECT_MQTT);
                }
                break;
            case APP_STATE_PUBLISH_SENSOR_DATA:
                Read_Sensors(&sensorData);
                printf("Building publish message\r\n");
                sprintf(command, 
                  "AT+PUBLISH={\"topic\":\"%s\",\"msg\":\"{\\\"event_data\\\":{\\\"iteration\\\":%u,\\\"timestamp\\\":%u,\\\"button\\\":%u,\\\"adc\\\":%u}}\"}\n",
                        MQTT_PUB_TOPIC,
                        (unsigned)sensorData.iteration, (unsigned)sensorData.timestamp, (unsigned)sensorData.buttonState, (unsigned)sensorData.adc
                        );
                printf("%s\r\n", command);
#if ENABLE_PUBLISH == 1
                Send_Command(command);
                app_state = APP_STATE_PUBLISH_SENSOR_DATA_CONFIRM;
#else
                set_timed_delay(PUB_INTERVAL_MS, APP_STATE_PUBLISH_SENSOR_DATA);
#endif
                LED0_On();
                break;
            case APP_STATE_PUBLISH_SENSOR_DATA_CONFIRM:
                if (new_response_available) {
                    LED0_Off();
                    if (isOKResponse(last_response)) {
                        printf("MQTT publish successful\r\n");
                        fail_count = 0;
                        set_timed_delay(PUB_INTERVAL_MS, APP_STATE_PUBLISH_SENSOR_DATA);
                    } else {
                        printf("ERROR: MQTT publish failed\r\n");
                        if (++fail_count >= 3) {
                            app_state = APP_STATE_DISCONNECT_WIFI;
                        } else {
                            set_timed_delay(PUB_INTERVAL_MS, APP_STATE_PUBLISH_SENSOR_DATA);
                        }
                    }
                } else if (Response_Elapsed_Time() > 10000) {
                    LED0_Off();
                    printf("ERROR: MQTT publish timed out\r\n");
                    if (++fail_count >= 3) {
                        app_state = APP_STATE_DISCONNECT_WIFI;
                    } else {
                        // try again with no additional delay
                    }
                }
                break;
            case APP_STATE_DISCONNECT_MQTT:
                /* not currently used */
                break;
            case APP_STATE_DISCONNECT_WIFI:
                printf("Disconnecting Wi-Fi\r\n");
                Send_Command("AT+DWIFI\n");
                app_state = APP_STATE_DISCONNECT_WIFI_CONFIRM;
                break;
            case APP_STATE_DISCONNECT_WIFI_CONFIRM:
                if (new_response_available) {
                    if (isOKResponse(last_response)) {
                        printf("Wi-Fi disconnect successful\r\n");
                        app_state = new_app_state(APP_STATE_INIT);
                    } else {
                        printf("ERROR: Wi-Fi disconnect failed\r\n");
                        app_state = new_app_state(APP_STATE_INIT);
                    }
                } else if (Response_Elapsed_Time() > 10000) {
                    printf("ERROR: Wi-Fi disconnect timed out\r\n");
                    app_state = new_app_state(APP_STATE_INIT);
                }
                break;
            case APP_STATE_TIMED_DELAY:
                if ((systick.tickCounter - timed_delay_start) >= timed_delay_duration) {
                    app_state = new_app_state(APP_STATE_INIT);
                }
            case APP_STATE_NONE:
            default:
                break;
        }

    }

    /* Execution should not come here during normal operation */

    return ( EXIT_FAILURE );
}

void Read_Sensors(SENSOR_DATA_T *sensorData)
{
    static uint32_t iteration = 0;
    // Read sensors and populate sensor data structure
    sensorData->iteration = iteration++;                            // sensor read count
    sensorData->timestamp = systick.tickCounter;                    // millisecond counter
    sensorData->buttonState = PORT_PinRead(PORT_PIN_PB11) ? 0 : 1;  // 1=pressed, 0=released
    sensorData->adc = ADC_ConversionResultGet();                    // free-running
}

/*******************************************************************************
 End of File
*/

